import { lazy, Suspense } from 'react';
import SimPlayer from '../components/SimPlayer';
import { SIM_SCRIPTS } from '../data/simScripts';

const REAL_COMPONENTS = {
  PasswordGen: lazy(() => import('../tools/real/PasswordGen')),
  UuidGen: lazy(() => import('../tools/real/UuidGen')),
  HashTools: lazy(() => import('../tools/real/HashTools')),
  TimeConvert: lazy(() => import('../tools/real/TimeConvert')),
  RegexLab: lazy(() => import('../tools/real/RegexLab')),
  JsonExplorer: lazy(() => import('../tools/real/JsonExplorer')),
  CsvToolkit: lazy(() => import('../tools/real/CsvToolkit')),
  YamlToolkit: lazy(() => import('../tools/real/YamlToolkit')),
  QrTool: lazy(() => import('../tools/real/QrTool')),
  LicenseHelper: lazy(() => import('../tools/real/LicenseHelper')),
  TodoManager: lazy(() => import('../tools/real/TodoManager')),
  SecretScan: lazy(() => import('../tools/real/SecretScan')),
  MarkdownToc: lazy(() => import('../tools/real/MarkdownToc')),
  PomodoroTimer: lazy(() => import('../tools/real/PomodoroTimer')),
};

export default function ToolPlayer({ tool }) {
  if (tool.kind === 'real') {
    const Comp = REAL_COMPONENTS[tool.component];
    if (!Comp) return <div style={{ color: '#f85149' }}>Missing component: {tool.component}</div>;
    return (
      <Suspense fallback={<div style={{ color: '#7d8590', padding: 24 }}>Loading…</div>}>
        <Comp />
      </Suspense>
    );
  }

  const script = SIM_SCRIPTS[tool.id];
  if (!script) return <div style={{ color: '#f85149' }}>Missing simulation script: {tool.id}</div>;

  return <SimPlayer key={tool.id} title={`${tool.cmd} — ${tool.name}`} subtitle={`_${tool.id}.sh`} script={script} />;
}
