<div align="center">

```
██╗   ██╗████████╗██╗██╗     ██╗████████╗██╗   ██╗██╗  ██╗██╗████████╗
██║   ██║╚══██╔══╝██║██║     ██║╚══██╔══╝╚██╗ ██╔╝██║ ██╔╝██║╚══██╔══╝
██║   ██║   ██║   ██║██║     ██║   ██║    ╚████╔╝ █████╔╝ ██║   ██║
██║   ██║   ██║   ██║██║     ██║   ██║     ╚██╔╝  ██╔═██╗ ██║   ██║
╚██████╔╝   ██║   ██║███████╗██║   ██║      ██║   ██║  ██╗██║   ██║
 ╚═════╝    ╚═╝   ╚═╝╚══════╝╚═╝   ╚═╝      ╚═╝   ╚═╝  ╚═╝╚═╝   ╚═╝
                                                   > C0ded by: ThatOn3Gu7
```

**A modular Bash toolbox for Linux, macOS, and Termux — 65 tools, one dashboard.**

[![License: MIT](https://img.shields.io/badge/License-MIT-cyan.svg?style=flat-square)](LICENSE)
[![Shell: Bash](https://img.shields.io/badge/Shell-Bash_5%2B-4EAA25?style=flat-square&logo=gnubash&logoColor=white)](https://www.gnu.org/software/bash/)
[![Platform](https://img.shields.io/badge/Platform-Linux%20%7C%20macOS%20%7C%20Termux-blueviolet?style=flat-square)](https://github.com/Thaton3gu7/UtilityKit)
[![CI](https://github.com/Thaton3gu7/UtilityKit/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/Thaton3gu7/UtilityKit/actions/workflows/ci.yml)
[![Tests](https://img.shields.io/badge/Smoke%20Tests-PASS%207%2F7-brightgreen?style=flat-square)](#testing)
[![Version](https://img.shields.io/badge/Version-5.3.0-orange?style=flat-square)](CHANGES.md)

</div>

---

## What is UtilityKit?

UtilityKit is a collection of 65 standalone Bash tools, each living in its own subdirectory with its own README. Every tool runs standalone, can be sourced as a library module, and is wired into a unified interactive dashboard (`main.sh`) with guided prompts and a direct CLI router.

The suite targets three platforms without modification:

```
  Linux         macOS         Termux / Android
  ─────         ─────         ────────────────
  Full support  Full support  ASCII-safe, emoji-friendly,
                              no root required
```

---

## Quick Start

```bash
# Clone and run
git clone https://github.com/Thaton3gu7/UtilityKit.git
cd UtilityKit
bash main.sh

# Or install a launcher
bash setup.sh
utility help
```

**Direct CLI** — no menu required:

```bash
bash main.sh env --dir . --compare
bash main.sh port 3000
bash main.sh pass --mode passphrase --words 6
bash main.sh json package.json --summary
bash main.sh toc README.md --apply --check-links
```

---

## Architecture

```
UtilityKit/
├── main.sh                  ← unified dashboard + CLI router
├── setup.sh                 ← installer (creates launcher in ~/.local/bin)
├── lib/
│   └── uk_common.sh         ← shared helpers: colors, prompts, platform detection
├── modules/
│   ├── _<tool>/
│   │   ├── _<tool>.sh       ← guarded entry point  (BASH_SOURCE guard)
│   │   └── _<tool>_README.md ← standalone docs
│   └── _cache_clean/
│       ├── _cache_clean.sh
│       └── plugins/         ← 17 package-manager plugins (npm, pip, cargo…)
├── docs/
│   ├── index.html           ← published documentation site (built from docs-site/)
│   ├── .nojekyll            ← disables Jekyll processing on GitHub Pages
│   ├── ICON_STYLE_GUIDE.md
│   └── ROADMAP_STATUS.md
├── docs-site/                  ← React + Vite source for the documentation site
│   ├── src/
│   ├── package.json
│   └── README.md            ← build, dev, and deploy instructions
└── tests/
    └── smoke_test.sh        ← syntax + behavioral smoke suite
```

Every script wraps its logic in a namespaced `*_main()` function and guards execution with:

```bash
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  tool_main "$@"
fi
```

This means `main.sh` can safely `source` all 51 scripts without side effects, color variable pollution, or unexpected `exit` calls.

---

## The Full Toolbox

### ── Core Suite ──

| Tool | Command | What it does |
|---|---|---|
| `_apply_changes` | `apply` | Enterprise-grade directory sync: dry-run preview → backup → apply → verify. Supports mirror delete, rollback on failure, concurrency locking, and audit logging. |
| `_rename_batch` | `rename` | Recursively rename or copy-rename files to a new extension. Preview budgets, transactional Ctrl+C rollback, safety exclusions for LICENSE/README/lockfiles. |
| `_move_in_batch` | `move` | Bulk copy or move files with exclusion patterns, optional flattening, collision-safe renaming, and Ctrl+C rollback. Sourceable as a library. |
| `_cache_clean` | `cacheclean` | Multi-manager cache cleaner with a plugin system. Two-confirmation deletion flow, orphan listing, responsive layout. See plugin list below. |
| `_symlink_manager` | `symlink` | Transactional symlink creator with automatic backup of existing targets. Dry-run default. |
| `_disk_analyzer` | `disk` | Largest-items disk usage explorer with optional in-place archive creation. Skips `.git` and VCS metadata. |

#### `_cache_clean` Plugins (17 built-in)

```
npm · yarn · pnpm · bun · pip · cargo · go · gem · composer
dotnet · conan · vcpkg · apt · pacman · dnf · brew · apk
```

Each plugin follows a five-function contract (`*_plugin_info`, `*_detect`, `*_get_cache_dirs`, `*_scan_cache`, `*_clean_orphans`) and is auto-loaded at runtime when its package manager is detected. Writing a new plugin requires only one file in `plugins/`.

---

### ── Roadmap Tools ───

| Tool | Command | What it does |
|---|---|---|
| `_env_manager` | `env` | `.env` profile switching, key comparison against `.env.example`, syntax validation, gpg/openssl encrypt/decrypt. |
| `_git_sweep` | `git` | Merged-branch detection, stash cleanup, `git clean -fdx` artifact sweep, `git gc --prune=now`. Safe preview before every action. |
| `_docker_janitor` | `docker` | Preview and prune stopped containers, dangling images, and orphaned volumes. Requires Docker daemon. Not shown in Termux dashboard. |
| `_project_scaffold` | `scaffold` | Starter project generator for Bash, Python Flask, Node CLI, and Go service stacks. Creates CI workflow, Dockerfile, Makefile, and README. |
| `_duplicate_finder` | `dup` | Size-first, hash-second duplicate detection. Actions: report, delete, or replace with hardlinks. Skips `.git`/`.hg`/`.svn`. |
| `_process_killer` | `proc` | RAM/swap bar chart, top-10 memory consumers, optional SIGTERM/SIGKILL by PID with post-signal confirmation. |
| `_port_inspector` | `port` | Find which process owns a local TCP port via `lsof` or `ss`. Interface summary, optional SIGTERM. |
| `_ssl_checker` | `ssl` | Certificate expiry (colored by days remaining), DNS A/AAAA/MX/TXT records, legacy TLS 1.0/1.1 probe. |
| `_api_tester` | `api` | One-off HTTP requests or saved/replayable profiles. Timing breakdown (DNS, TCP, TTFB, total), `jq` pretty-print, status-code coloring. |
| `_password_gen` | `pass` | XKCD-style passphrases from a 37-word list, or random strings from a 72-char charset. Entropy display. Clipboard copy via `wl-copy`/`xclip`/`pbcopy`/`termux-clipboard-set`. |
| `_ssh_assistant` | `ssh` | Parses `~/.ssh/config`, lists named hosts, connects by number, runs `ssh-copy-id`. Explains auth-only disconnects from GitHub/GitLab/Bitbucket. |
| `_shredder` | `shred` | Multi-pass overwrite using `shred` or `/dev/urandom` fallback. Configurable passes (default 3). Dry-run preview with method/passes display. |
| `_media_convert` | `media` | Batch image conversion via ImageMagick or ffmpeg fallback. Video conversion via ffmpeg libx264. EXIF stripping, quality control, directory scanning. |
| `_markdown_toc` | `toc` | Insert or refresh TOC using `<!-- utilitykit:toc:start/end -->` markers. Relative link validation. Pipe-table column alignment via Python. |
| `_pomodoro` | `pomodoro` | Work/break cycle timer with a live progress bar, session log at `~/.local/state/utilitykit/pomodoro.log`, and Termux vibration support. |
| `_cheat_sheet` | `cheat` | Personal markdown snippet store with tagging, search, and a persistent interactive loop. Files at `~/.local/share/utilitykit/cheat_sheets/`. |

---

### ── Expanded Utility Set ───

| Tool | Command | What it does |
|---|---|---|
| `_network_probe` | `network` | Ping, DNS lookup, public IP via `curl`, route tracing with `traceroute`/`tracepath`. Graceful fallbacks when tools are missing. |
| `_cron_manager` | `cron` | List, add (with format validation), and remove crontab entries. Dry-run default, `--apply` to write. |
| `_dotenv_vault` | `dotenv` | Encrypt individual `KEY=value` pairs in a `.env` file to `ENC::` tokens using gpg symmetric encryption. Backup on apply. |
| `_disk_health` | `disk-health` | SMART health and attribute report via `smartctl`. Auto-detects first disk. Optional short self-test trigger. |
| `_service_watcher` | `service` | HTTP endpoint status and response-time checks. Saved URL profiles, looping interval mode, bell on failure. |
| `_git_stats` | `git-stats` | Commit counts by author, most-changed files, branch activity sorted by committer date. `--since`/`--until`/`--author` filters. |
| `_backup_sync` | `backup` | Dry-run-first backup wrapper around `rsync` (with `--delete` support) or `cp`/`find` fallback. Configurable excludes. |
| `_weather` | `weather` | Fetches current weather from `wttr.in`. Caches last result for offline fallback. Metric/imperial toggle. |
| `_json_explorer` | `json` | Python-backed JSON pretty-print, dot-path extraction, key listing, and structure summary. Reads stdin or file. |
| `_tmux_session` | `tmux` | Friendly wrapper for `tmux` list/new/attach/kill. Clear install hint for Termux. |
| `_font_inspector` | `font` | Terminal glyph sample output (ASCII, box-drawing, Powerline). Optional `fc-list` font enumeration with filter. |
| `_toolbox_bootstrap` | `toolbox` | Audits recommended CLI tools (`fzf`, `rg`, `fd`, `bat`, `eza`, `jq`, `curl`, `git`, `tmux`, `gh`, `zoxide`, `tldr`) and prints `[OK]`/`[MISSING]`. |
| `_project_search` | `search` | Text or filename search with `rg` → `grep -RIn` → `find` fallback chain. |
| `_github_helper` | `github` | Thin wrapper around `gh` for auth status, PR list, issue list, and workflow run list. |
| `_link_checker` | `links` | Python-backed Markdown link validator. Checks local relative links by default; optional HTTP/HTTPS live checks with configurable timeout. |
| `_log_inspector` | `log-inspect` | Grep for errors/warnings/failures with configurable pattern. Top-10 repeated line frequency summary. |
| `_csv_toolkit` | `csv` | Python-backed CSV column header print and row preview with configurable head count. |
| `_hash_tools` | `hash` | `sha256sum` (or `shasum`/`md5sum` fallback) over files and directory trees. |
| `_archive_manager` | `archive` | List, safely extract (with path traversal guard), and create `.tar.gz` or `.zip` archives. |
| `_system_snapshot` | `snapshot` | Compact diagnostic summary: OS, platform, disk usage. Optional file output. |
| `_open_files` | `open-files` | Find processes using a path or port via `lsof`. |
| `_battery_doctor` | `battery` | Battery status via `termux-battery-status` → `pmset` → `acpi`. Top CPU/memory process list. |
| `_release_helper` | `release` | Git status, recent commit log, optional tag creation with `--apply` guard. |
| `_license_helper` | `license` | Detects `LICENSE*`/`COPYING*` in current directory. Generates MIT or Apache 2.0 text. |
| `_todo_manager` | `todo` | Plain-text TSV task tracker with tags, `--done` by line number, and `--search`. |
| `_update_managers` | `update` | Detect and update 60+ package managers (apt, brew, npm, pip, cargo, winget, …) with a live per-command spinner and extracted failure reasons. Aliases: `update-managers`, `upgrade`. |
| `_installed` | `installed` | 📦 List every installed package (native + language package managers) and each executable discovered on `$PATH`. Live per-manager spinner; versions printed as `[ - name → vX ]`. Read-only inventory across apt, brew, npm, pip, cargo, and more. |

---

## Dashboard Navigation

```
bash main.sh         ← opens the interactive dashboard

UtilityKit Master Suite — Tool 1 of 49

  ➔  ↻ Apply Changes      (Robust Directory Synchronization)
     ✎ Batch Rename       (Recursive File Renaming & Copying)
     🗑 Cache Cleaner     (Intelligent System Cache Cleanup)
     ► Symlink Manager    (Dotfiles & System Config Management)
     ◆ Disk Analyzer      (Storage Inspection & Quick Archiving)
     ◎ Env Manager        (compare, validate, switch .env profiles)
     ⑂ Git Sweep          (clean merged branches, stashes, artifacts)
     ▣ Project Scaffold   (generate starter projects from templates)
     ▼  (scroll down for more tools)

 Use ▲/▼ or j/k : Scroll Tools         [Enter] : Execute selected
                                       [q]     : Exit UtilityKit
```

All 65 tools live in a single unified scroll list — no nested "More tools"
pages. Highlights:

- **Arrow keys** (`▲`/`▼`) or **Vim keys** (`k`/`j`) move the selection.
- **Enter** runs the highlighted tool's guided wizard.
- **q** exits.
- 8 tools are visible in the viewport; `▲`/`▼` indicators show when more
  tools exist above or below the window.
- The terminal cursor is hidden while the menu is active (via `tput civis`)
  and automatically restored on exit, Ctrl+C, or SIGTERM via an `EXIT` trap.

Every tool has a guided interactive wizard when launched from the dashboard or invoked without arguments. Direct CLI flags still work for scripting.

---

## Shared Library (`lib/uk_common.sh`)

All tools source `lib/uk_common.sh`, which provides:

```
uk_prompt            read -r with /dev/tty  (safe in subshells and pipelines)
uk_confirm           [Y/n] prompt with non-interactive fallback
uk_header            section header with color + divider
uk_section_title     inline section label
uk_note / uk_info    ℹ blue info line
uk_success           ✔ green success line
uk_warn              ⚠ yellow warning to stderr
uk_error             ✖ red error to stderr
uk_die               error + return 1
uk_bar               ASCII progress bar  (# fill, - empty)
uk_has_cmd           command -v wrapper
uk_is_interactive    [[ -t 0 && -t 1 ]]
uk_platform          linux | macos | termux
uk_abs_path          realpath → python3 → PWD fallback
uk_data_dir          ~/.local/share/utilitykit/  (auto-created)
uk_state_dir         ~/.local/state/utilitykit/  (auto-created)
uk_slugify           lowercase + hyphen-safe name
uk_copy_to_clipboard wl-copy → xclip → pbcopy → termux-clipboard-set → clip.exe
uk_pick_clipboard_cmd returns first available clipboard command
uk_repeat            repeat a character N times
uk_now / uk_stamp    date helpers
```

The library uses a load-once guard (`UK_COMMON_SH_LOADED`) so sourcing it multiple times from nested scripts is safe.

### User config file

On load, the library applies `${XDG_CONFIG_HOME:-~/.config}/utilitykit/config` (override the path with `UK_CONFIG_FILE`), so suite-wide defaults can be set once instead of retyped as flags:

```sh
# ~/.config/utilitykit/config
DEFAULT_CACHE_OLDER_THAN=30
DEFAULT_PASSPHRASE_WORDS=6
NO_UNICODE=1          # comments allowed
```

The file is parsed, never sourced — only `[export] KEY=VALUE` lines (bare or quoted values) are accepted, so a stray command can't execute and a typo can't abort tools under `set -eu`. Malformed lines are skipped with a warning. Precedence: flag > environment > config file > built-in default, so `NO_COLOR=1 bash main.sh` always beats the file.

---

## Visual System

UtilityKit uses standard Unicode symbols that render in common terminal fonts, with plain ASCII fallbacks for dumb terminals, pipes, and `NO_COLOR` environments.

```
  ✔  Success       [OK]
  ✖  Error         [X]
  ⚠  Warning       [!]
  ℹ  Info          i
  ⚙  Working       *
  ❯  Prompt        >
  ●  Bullet        *
  ◆  Highlight     <>
  ╭─╮ Box corners  +-+
  █░ Progress bar  #.
```

Color is enhancement, never the only channel of meaning. `NO_COLOR=1` and `NO_UNICODE=1` are both respected globally.

---

## Installing

### Homebrew (macOS / Linux)

The repository doubles as a Homebrew tap — no clone needed:

```bash
brew tap thaton3gu7/utilitykit https://github.com/ThatOn3Gu7/UtilityKit.git
brew install utilitykit          # tagged release
brew install --HEAD utilitykit   # latest master (use this until the first vX.Y.Z release is tagged)
utility
```

The formula installs the `utility` launcher, bash/zsh tab-completions, and depends on Homebrew's `bash` (the suite needs bash ≥ 4; macOS ships 3.2).

### Termux

Grab the `.deb` from the latest GitHub Release — no clone needed:

```bash
curl -fLO https://github.com/ThatOn3Gu7/UtilityKit/releases/latest/download/utilitykit_all.deb
pkg install ./utilitykit_all.deb
utility
```

Uninstall with `pkg uninstall utilitykit`. The package installs to `$PREFIX/opt/utilitykit` with a `utility` launcher in `$PREFIX/bin` and tab-completions wired into the system bash/zsh completion dirs. To build the `.deb` yourself from a checkout: `bash packaging/build-termux-deb.sh` (see [`packaging/README.md`](packaging/README.md)).

### From a checkout (`setup.sh`)

```bash
# Interactive — prompts for launcher name, install dir, and PATH update
bash setup.sh

# Non-interactive
bash setup.sh --no-menu --launcher-name utility --install-dir ~/.local/share/utility --bin-dir ~/.local/bin

# After install
utility help
utility env --dir . --compare
utility port 3000 --kill
```

`setup.sh` copies every `modules/_*/` tool directory (preserving the `modules/` layout `main.sh` expects), along with `lib/`, `docs/`, `tests/`, and the top-level files, to the install location. It creates a one-line launcher wrapper (`exec "$INSTALL_DIR/main.sh" "$@"`) in `bin-dir` and optionally appends `bin-dir` to `~/.bashrc`/`~/.zshrc` (and `ZDOTDIR/.zshrc` when set). In `--no-menu` mode the installer shows a numbered step tracker and a spinner on the longer steps (respecting `NO_COLOR`/`NO_UNICODE`); running it from a checkout that lacks `main.sh` will clone the repo first.

---

## Documentation site

The user-facing documentation lives in [`docs-site/`](docs-site/) — a React + Vite
single-page app that inlines to a single self-contained `dist/index.html` via
`vite-plugin-singlefile`.

```bash
cd docs-site
npm install
npm run dev            # local preview with HMR (http://localhost:5173)
npm run build          # emit dist/index.html
npm run deploy:docs    # build + copy dist/index.html → ../docs/index.html
```

The bundle is deployed to GitHub Pages two ways, either works standalone:

1. **GitHub Actions** — [`.github/workflows/pages.yml`](.github/workflows/pages.yml)
   builds and publishes on every push to `master` that touches `docs-site/` or
   `docs/`. Enable via *Settings → Pages → Source: GitHub Actions*.
2. **Serving `/docs`** — the built bundle is committed to
   [`docs/index.html`](docs/index.html) alongside a `docs/.nojekyll` marker.
   Set *Settings → Pages → Source: Deploy from a branch → master → /docs* to
   use it.

See [`docs-site/README.md`](docs-site/README.md) for the full build and theming
notes.

---

## Testing

```bash
bash tests/smoke_test.sh
# PASS=7 FAIL=0
```

The suite covers:

- **Syntax check** — `bash -n` across every `.sh` file in the repository
- **Help/routing** — `main.sh help`, `setup.sh --help`, and `main.sh <cmd> --help` for all routed commands
- **Core tool smoke** — apply changes mirror mode, rename copy mode, move with excludes, symlink backup/create, disk scan, cache cleaner entrypoint
- **Roadmap tool smoke** — env compare/validate, git sweep branch detection, scaffold generation, duplicate deletion, process kill, port inspect, API test, password gen, SSH config parse, shredder, media convert help, markdown TOC insertion, pomodoro short-duration, cheat sheet add/search
- **New utility smoke** — JSON path extraction, link checking, CSV column inspection, hash generation, git stats, backup sync, license generation, toolbox audit, font glyph check, system snapshot
- **Update Managers smoke** — `update --list` and a full `update --yes --dry-run`
- **Doctor / registry integrity** — `main.sh doctor --quick` validates the tool registry against the filesystem and dispatch

A deeper behavioral audit lives in `tests/deep_review_test.sh` (password
entropy, weather URL encoding, license detection, todo state, archive
traversal rejection, cron validation, duplicate scan, portability audits).

### Continuous Integration

Every push and pull request against `master`/`main` runs
[`.github/workflows/ci.yml`](.github/workflows/ci.yml), which gates ten
independent jobs before merge:

| Job | What it checks |
|---|---|
| `lint` | `shellcheck -S error` across every `*.sh` |
| `syntax` | `bash -n` matrix on Ubuntu and macOS |
| `smoke` | `tests/smoke_test.sh` matrix on Ubuntu and macOS |
| `deep-review` | `tests/deep_review_test.sh` behavioral audits |
| `route-coverage` | `bash main.sh <cmd> --help` for every routed command |
| `standalone-tools` | `bash _<tool>/_<tool>.sh --help` for every tool |
| `no-color` | Smoke suite with `NO_COLOR=1 NO_UNICODE=1` |
| `installer` | `bash setup.sh --no-menu` produces a working launcher |
| `secret-scan` | `gitleaks` on the full history |
| `ci-summary` | Fails the workflow if any prior job did not succeed |

Dependabot keeps GitHub Actions versions current; PRs are guided by the
touchpoints/verification checklist in `.github/PULL_REQUEST_TEMPLATE.md`.

### Registry & `doctor`

All tools are registered once in `UK_REGISTRY` (in `main.sh`); the lazy-loader map
and dashboard menu are derived from it. Run a health check any time with:

```bash
./main.sh doctor          # full check (includes per-tool --help)
./main.sh doctor --quick  # skip the per-tool --help pass
```

---

## Writing a Plugin for `_cache_clean`

Drop a file in `_cache_clean/plugins/` named after the package manager:

```bash
# plugins/mybuild.sh

mybuild_plugin_info() {
  printf 'mybuild|MyBuild|🔨\n'   # id|display_name|icon
}

mybuild_detect() {
  command -v mybuild >/dev/null 2>&1
}

mybuild_get_cache_dirs() {
  printf '%s\n' "$HOME/.mybuild/cache"
}

mybuild_scan_cache() {
  local dir
  while IFS= read -r dir; do
    [ -z "$dir" ] && continue
    [ ! -d "$dir" ] && { cc_emit_err "$dir" "not found"; continue; }
    cc_emit_tot "$dir" "$(cc_du_kb "$dir")"
    while IFS= read -r f; do
      [ -z "$f" ] && continue
      cc_emit_orphan "$dir" "$f" "stale cache older than ${CC_OLDER_THAN} days"
    done < <(cc_find_old "$dir" "$CC_OLDER_THAN")
  done < <(mybuild_get_cache_dirs)
}

mybuild_clean_orphans() {
  cc_clean_orphans_from_file "$1"
}
```

Helper functions available to all plugins: `cc_find_old DIR DAYS`, `cc_find_partial DIR`, `cc_du_kb DIR`, `cc_file_size FILE`, `cc_emit_tot`, `cc_emit_orphan`, `cc_emit_err`, `cc_clean_orphans_from_file`.

---

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for the full guide. Key rules:

- Every tool lives in `_tool_name/_tool_name.sh` with its own `_tool_name_README.md`
- Wrap execution in a namespaced `*_main()` and guard with `[[ "${BASH_SOURCE[0]}" == "${0}" ]]`
- Register traps **inside** `*_main()`, never at the top level
- Source `lib/uk_common.sh` for visuals and helpers — don't re-implement colors
- Add a `main.sh` route, a dashboard wizard, and a `setup.sh` directory entry
- Use semantic commits: `feat(tool):`, `fix(tool):`, `refactor(tool):`, `docs:`

---

## Changelog

See [`CHANGES.md`](CHANGES.md) for the full versioned changelog.

**v5.10.0** - current — Package-manager install paths, removing the `git clone` step entirely: `Formula/utilitykit.rb` turns the repo into a Homebrew tap (`brew tap thaton3gu7/utilitykit <repo-url> && brew install utilitykit`, with `--HEAD` support and bash ≥ 4 guaranteed via the `bash` dependency), and `packaging/build-termux-deb.sh` builds a Termux `.deb` (`pkg install ./utilitykit_all.deb`) with launcher, completions, and `Depends: bash` wired in. A new `Release` workflow publishes the `.deb` (plus a stable-named `utilitykit_all.deb` alias) on every `vX.Y.Z` tag and verifies the tag matches `UK_VERSION`; `packaging/update-formula.sh` pins the formula's `url`/`sha256` to a released tag.

**v5.9.0** — Shell tab-completions generated from `UK_REGISTRY`: new `scripts/gen_completions.sh` emits `completions/utility.bash` and `completions/utility.zsh` from the registry plus each tool's flag-parsing `case` labels, so `utility <TAB>` completes all commands and `utility <cmd> <TAB>` offers that tool's flags (zsh also shows per-command descriptions and files alongside). `setup.sh` gained step 7: copies `scripts/` + `completions/` into the install dir and idempotently wires a `UK_COMPLETE_CMD='<launcher>' source ...` line into `~/.bashrc` / `~/.zshrc` / `$ZDOTDIR/.zshrc`, so custom launcher names complete too.

**v5.8.0** — Shared `uk_output_format` table/json/csv rendering in `lib/uk_common.sh`: canonical JSON escaping and object/array builders (`uk_json_escape`, `uk_json_str`, `uk_json_lit`, `uk_json_obj`, `uk_json_arr` — python3-aware with a pure-bash fallback) plus a row accumulator (`uk_table_init` / `uk_table_row` / `uk_table_count` / `uk_table_render`) that renders one dataset as a boxed table, JSON array, or CSV, auto-resolved via `UK_FMT` / `--format` / `--json` / `--csv` / TTY detection. `_dns_probe`, `_yaml_toolkit`, and `_uuid_gen` migrated off their hand-rolled JSON escapes.

**v5.7.0** — Safe-by-default write/delete hardening: `_image_tool` (`resize`, `convert`, `strip`, `optimize`, `thumb`) and `_pdf_toolkit` (`merge`, `split`, `compress`, `rotate`) now preview only and require `--apply` to write output, closing the gap where `_image_tool optimize` rewrote files in place with no preview; their wizards prompt before writing. `CONTRIBUTING.md` now documents the project-wide rule (and a safety-matrix table) that any tool mutating the filesystem or system state must protect the user by default, plus the single-source-of-truth version policy for the whole suite.

**v5.6.0** — User config file support: `lib/uk_common.sh` applies `${XDG_CONFIG_HOME:-~/.config}/utilitykit/config` (override with `UK_CONFIG_FILE`) whenever it is sourced, letting suite-wide defaults (`DEFAULT_CACHE_OLDER_THAN=30`, `NO_UNICODE=1`, ...) be set once instead of retyped as flags. Parsed as `[export] KEY=VALUE` lines — never sourced — so stray commands can't execute and typos can't abort tools under `set -eu`; malformed lines are skipped with a warning. Precedence: flag > environment > config file > built-in default.

**v5.5.0** — Canonical progress feedback in the shared library: new `uk_spinner` (braille/ASCII frames, `NO_COLOR`/`NO_UNICODE` at call time, width-safe redraws, non-TTY degradation, `--prefix`/`--label-file`/`--elapsed`/`--interval`) and `uk_fake_progress` (indeterminate accelerating percent bar). `setup.sh`, `_cache_clean`, and `_update_managers` now delegate their spinners to `uk_spinner`; `_media_convert` and `_disk_analyzer` delegate their percent bars to `uk_fake_progress` — removing ~200 lines of duplicated animation code.

**v5.4.0** — `doctor` gained an opt-in `--fix` flag: creates missing `modules/_<tool>/_<tool>_README.md` stubs from registry metadata, and flags orphan tool directories with a suggested `git rm -r` command (never auto-deletes). Doctor now also checks each registry tool for its README, and the orphan-directory scan was repaired (it globbed the repo root instead of `modules/` and never matched anything).

**v5.3.0** — Security & stability hardening pass across the entire toolkit, plus follow-up bug fixes from the review. Highlights: fail-fast error propagation (no more false-success diagnostics), command/arithmetic injection and word-splitting fixes (`--` terminators, `printf -v` instead of `eval`, quoted `TZ=`/`env` assignments), NUL-delimited filename traversal, path-traversal/containment guards, secure temp/state file modes (600/700) and non-predictable PID paths, archive link/special-file extraction validation, TLS-by-default and verified-HTTPS transports, PID-reuse/unrelated-process signal protection, and removal of suppressed stderr / masked exit statuses. Notable fixes: `_ssh_tunnel` can again kill/restart stopped tunnels; `_ip_info --json` no longer truncates on a transient GeoIP error; `_installed` no longer aborts the whole inventory on a benign empty parse; `_secret_scan` tolerates a single unreadable directory; `_cache_clean` size validation no longer false-fails on `wc -c` padding; `_yt_download` metadata parsing is immune to stderr contamination; `_cron_manager` preserves first-entry adds; `_main.sh` restores the width-gate bail behavior.

**v5.2.5** — Upgraded from 5.2.1: added the `_installed` tool (read-only package & PATH inventory with a live per-manager spinner and per-package version detection); refreshed documentation and doc-site entry.

**v5.2.1** — Interactive directory pickers hardened and expanded across `_apply_changes`, `_move_in_batch`, and `_rename_batch` (banner-safe redraw, 📁/🔗 icons, two-step source+destination wizard, surgical flicker-free pointer redraw, full CSI escape parsing, `stty -echo`, DSR-based banner-aware viewport, `exit 130` on Ctrl+C, and safe `mv` rollback). Replaced the `UK_I_STAR` (✦) glyph with `UK_I_CLAUDE` (✽). Documentation promoted to a canonical React + Vite + Tailwind single-file site in `docs-site/` (formerly `webAPP/`), deployed to GitHub Pages.

**v5.1.1** — Added interactive directory picker menu to `_apply_changes` and resolved unbound variable bugs (array iteration fixes and global color initialization)

**v5.0.0** — Unified single project version (`UK_VERSION` in `lib/uk_common.sh`); all per-tool versioning removed. Repository reorganized: every `_<tool>/` now lives under `modules/`.  
**v4.2.0** — unified arrow-key scroll menu (8-row viewport), hidden cursor with restore trap, `set -euo pipefail` re-enabled  
**v4.1.1** — cache cleaner runtime fixes under `set -e`, terminal-width hardening  
**v4.1.0** — dashboard restyle, paged more-tools navigation, expanded interactive prompts  
**v4.0.0** — initial unified suite: 18 roadmap tools + shared library + smoke suite  

---

## License

[MIT](LICENSE) — use, modify, and share freely.

---

<div align="center">

*Built for developers who live in the terminal.*

</div>
